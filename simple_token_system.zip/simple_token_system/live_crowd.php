<?php
    require_once 'config.php';
    
    $depts = $conn->query("SELECT id,name FROM departments ORDER BY name")->fetch_all(MYSQLI_ASSOC);
?>


<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Live Crowd Display</title>
        <link rel="stylesheet" href="assets/style.css">
        <style>
        body
        {
            background:#111;color:#fff
        }
        
        h1
        {
            color:#0ff
        }
        
        table
        {
            width:100%;border-collapse:collapse;margin-top:20px
        }
        
        th,td
        {
            padding:16px;border:1px solid #333;font-size:20px
        }
        
        th
        {
            background:#0ff;color:#111
        }
        
        .current
        {
            color:#ff0;font-weight:bold
        }

        </style>

    </head>
    <body>
            <div class="container"><h1>Live Token Display</h1>
            <table>
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Current Token</th>
                        <th>Next Tokens</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($depts as $d):
                    $cur = $conn->query("SELECT token_no FROM tokens WHERE department_id=".intval($d['id'])." AND status IN ('called','processing') ORDER BY updated_at DESC LIMIT 1")->fetch_assoc();
                    $next_q = $conn->query("SELECT token_no FROM tokens WHERE department_id=".intval($d['id'])." AND status='waiting' ORDER BY created_at ASC LIMIT 3"); $nexts=[];
                    while
                        ($n=$next_q->fetch_assoc())
                        $nexts[]=$n['token_no'];
                    ?>
                    <tr>
                        <td><?=htmlspecialchars($d['name'])?></td>
                        <td class="current"><?=htmlspecialchars($cur['token_no']??'--')?></td>
                        <td><?=htmlspecialchars(implode(', ',$nexts)?:'--')?></td>
                    </tr>
                    
                    <?php endforeach;
                    ?>
                </tbody>
            </table>
            <p style="color:#ccc;margin-top:12px">Auto-refresh every 10s</p>
        </div>
        
        
        <script>setTimeout(()=>location.reload(),10000);</script>
</body>
</html>
