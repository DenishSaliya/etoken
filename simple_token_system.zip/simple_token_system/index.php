<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>E-Token - Smart Queue Management</title>
  <link rel="stylesheet" href="assets/landing.css">
</head>
<body>
  <!-- Hero Section -->
  <header class="hero">
    <div class="hero-content">
      <h1>Welcome to <span>E-Token</span></h1>
      <p>India's Smart Token & Queue Management System for Government Services</p>
      <div class="hero-buttons">
        <a href="index1.php"  class="btn active">Book Token</a>
        <a href="token_status.php" class="btn secondary">Check Token Status</a>
        <a href="admin/login.php" class="btn">Admin</a>
        <a href="dept_admin/login.php" class="btn secondary">Dept. Admin</a>
        <a href="helpdesk.php" class="btn">Help Desk</a>
      </div>
    </div>
  </header>

  <!-- Features -->
  <section class="features">
    <h2>✨ Why Choose E-Token?</h2>
    <div class="feature-grid">
      <div class="feature-card">
        <h3>📱 Easy Booking</h3>
        <p>Book tokens using your mobile number in just a few steps.</p>
      </div>
      <div class="feature-card">
        <h3>👥 Reduced Crowds</h3>
        <p>Avoid long queues with smart digital queue management.</p>
      </div>
      <div class="feature-card">
        <h3>📊 Live Tracking</h3>
        <p>Track token status and waiting time in real-time.</p>
      </div>
      <div class="feature-card">
        <h3>🌐 Multi-Department</h3>
        <p>One platform to manage multiple government services.</p>
      </div>
    </div>
  </section>

  <!-- About -->
  <section class="about">
    <h2>About <E-Token></E-Token></h2>
    <p>
      E-Token is a digital solution designed to make government services faster, 
      more transparent, and accessible to all citizens. With features like mobile booking, 
      live updates, and departmental dashboards, we aim to eliminate unnecessary waiting 
      and improve citizen experience.
    </p>
  </section>

  <!-- Footer -->
  <footer>
    <p>© 2025 E-Token Service | Designed for Smart Governance</p>
  </footer>
</body>
</html>
