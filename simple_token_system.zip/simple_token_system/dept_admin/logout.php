<?php
    require_once '../config.php';
    unset($_SESSION['dept_admin_id'],$_SESSION['dept_admin_name'],$_SESSION['dept_admin_department_id']);
    header('Location: login.php');