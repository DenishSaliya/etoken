<?php
require_once '../config.php';
if(empty($_SESSION['dept_admin_id']))
    {
        header('Location: login.php');
        exit;
    }
    
    $dept_id=intval($_SESSION['dept_admin_department_id']);


    if(isset($_GET['call_next']))
        {
            $stmt=$conn->prepare("SELECT id FROM tokens WHERE department_id=? AND status='waiting' ORDER BY created_at ASC LIMIT 1");
            $stmt->bind_param('i',$dept_id);
            $stmt->execute();
            $row=$stmt->get_result()->fetch_assoc();
            if($row){ $id=$row['id'];
                $upd=$conn->prepare("UPDATE tokens SET status='called', called_by_dept_admin_id=?, updated_at=NOW() WHERE id=?");
                $admin_id=intval($_SESSION['dept_admin_id']);
                $upd->bind_param('ii',$admin_id,$id);
                $upd->execute();
            }
            header('Location: dashboard.php');
            exit;
        }

        if(isset($_GET['change_status'])&&isset($_GET['token']))
            {
                $token=intval($_GET['token']);
                $new=$_GET['change_status'];
                if(in_array($new,['processing','completed','skipped']))
                    {
                        $upd=$conn->prepare("UPDATE tokens SET status=?, updated_at=NOW() WHERE id=? AND department_id=?");
                        $upd->bind_param('sii',$new,$token,$dept_id);
                        $upd->execute();
                    }
                        header('Location: dashboard.php');
                        exit;
            }

        $stmt=$conn->prepare("SELECT t.*, p.first_name, p.mobile, c.title concern_title FROM tokens t JOIN public_users p ON t.public_user_id=p.id JOIN concerns c ON t.concern_id=c.id WHERE t.department_id=? ORDER BY t.created_at ASC");
        $stmt->bind_param('i',$dept_id);
        $stmt->execute(); $tokens=$stmt->get_result();
        $deptName=$conn->query("SELECT name FROM departments WHERE id=$dept_id")->fetch_assoc()['name'];
?>


<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Dept Admin</title>
        <link rel="stylesheet" href="../assets/style.css">
    </head>
    <body>
        <div class="container"><h1>Department Admin - <?=htmlspecialchars($deptName)?></h1>
        <div class="nav"><a href="dashboard.php?call_next=1">Call Next</a> | <a href="logout.php">Logout</a></div>
        <div class="card"><table class="tbl">
            <tr>
                <th>ID</th>
                <th>Token</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Concern</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            
        <?php
            while($r=$tokens->fetch_assoc()):
        ?>
            <tr>
                <td><?=$r['id']?></td>
                <td><?=htmlspecialchars($r['token_no'])?></td>
                <td><?=htmlspecialchars($r['first_name'])?></td>
                <td><?=htmlspecialchars($r['mobile'])?></td>
                <td><?=htmlspecialchars($r['concern_title'])?></td>
                <td><?=htmlspecialchars($r['status'])?></td>
                <td><?php if($r['status']=='called'||$r['status']=='waiting'): ?>
                    <a href="dashboard.php?change_status=processing&token=<?=$r['id']?>">Processing</a>
                    
                    <?php
                        endif;
                    ?>
                    <?php
                        if($r['status']!='completed'): ?><a href="dashboard.php?change_status=completed&token=<?=$r['id']?>">Complete</a>
                    
                    <?php
                        endif;
                    ?><a href="dashboard.php?change_status=skipped&token=<?=$r['id']?>">Skip</a>
                </td>
            </tr>
                
                <?php
                    endwhile;
                ?>
                </table>
            </div>
        </div>
    </body>
</html>
