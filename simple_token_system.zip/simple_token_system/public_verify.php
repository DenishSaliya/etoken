<?php
    require_once 'config.php';

    if
    (empty($_SESSION['demo_otp'])||empty($_SESSION['public_user_id_pending']))
        {
            header('Location: index1.php');
            exit;
        }

        $otp=$_SESSION['demo_otp'];
        $mobile=$_SESSION['demo_otp_mobile'];
?>



<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Verify OTP</title>
        <link rel="stylesheet" href="assets/style.css">
    </head>
    <body>
        <div class="container"><h1>Verify OTP</h1>
        <div class="card"><p>Mobile:
            <b><?=htmlspecialchars($mobile)?></b></p>
            <p><b>OTP:</b>
            <span style="font-size:20px;color:green;"><?=$otp?></span></p>


            <form method="post" action="public_api/verify_otp.php">
                <label>Enter OTP</label><input name="otp" required>
                <button>Verify & Login</button>
            </form>
            <p><small>Demo only.</small></p>
        </div>
        </div>
    </body>
</html>
