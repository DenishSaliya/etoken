<?php
    require_once '../config.php';
    if(empty($_SESSION['public_user_id']))
        {
            header('Location: ../index1.php');
            exit;
        }

        $first=trim($_POST['first_name']??'');
        $middle=trim($_POST['middle_name']??'');
        $last=trim($_POST['last_name']??'');

        $gender=$_POST['gender']??'Male';
        $age=intval($_POST['age']??0);
        $mobile=trim($_POST['mobile']??'');
        $email=trim($_POST['email']??'');

        $department_id=intval($_POST['department_id']??0);
        $concern_id=intval($_POST['concern_id']??0);

        $uid=intval($_SESSION['public_user_id']);
        $uupd=$conn->prepare("UPDATE public_users SET first_name=?, middle_name=?, last_name=?, gender=?, age=?, mobile=?, email=? WHERE id=?");

        $uupd->bind_param('sssssssi',$first,$middle,$last,$gender,$age,$mobile,$email,$uid);
        $uupd->execute();

        $date=date('Ymd');
        $prefixStmt=$conn->prepare("SELECT name FROM departments WHERE id=?");
        $prefixStmt->bind_param('i',$department_id);
        $prefixStmt->execute();
        $pn=$prefixStmt->get_result()->fetch_assoc();

        $deptName = $pn ? preg_replace('/\s+/','',strtoupper($pn['name'])) : 'DPT';

        $seqStmt=$conn->prepare("SELECT COUNT(*) as c FROM tokens WHERE department_id=? AND DATE(created_at)=CURDATE()");
        $seqStmt->bind_param('i',$department_id);
        $seqStmt->execute();
        $seq=$seqStmt->get_result()->fetch_assoc()['c']+1;

        $token_no = $deptName.'-'.$date.'-'.str_pad($seq,3,'0',STR_PAD_LEFT);

        $ins=$conn->prepare("INSERT INTO tokens (token_no, public_user_id, department_id, concern_id) VALUES (?,?,?,?)");
        $ins->bind_param('siii',$token_no,$uid,$department_id,$concern_id);
        $ins->execute();

        header('Location: ../receipt.php?token_no='.urlencode($token_no));
        exit;
