<?php
    require_once '../config.php';
    $dept=intval($_GET['dept']??0);
    $out=[];
    
    if($dept)
        {
            $stmt=$conn->prepare("SELECT id,title FROM concerns WHERE department_id=? ORDER BY title");
            $stmt->bind_param('i',$dept);
            $stmt->execute();
            $res=$stmt->get_result();
            
            while($r=$res->fetch_assoc()) $out[]=$r;
        }
        
        header('Content-Type: application/json');
        echo json_encode($out);
