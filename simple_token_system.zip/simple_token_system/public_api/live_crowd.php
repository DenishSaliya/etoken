<?php
    require_once '../config.php';
    
    $dept=intval($_GET['dept']??0);
    $out=['waiting'=>0];
    
    if($dept)
        {
            $stmt=$conn->prepare("SELECT COUNT(*) AS c FROM tokens WHERE department_id=? AND status IN ('waiting','called')");
            $stmt->bind_param('i',$dept);
            $stmt->execute();
            $out['waiting']=(int)$stmt->get_result()->fetch_assoc()['c'];
        }
        
        header('Content-Type: application/json');
        echo json_encode($out);