<?php
    require_once '../config.php';

    $otp=trim($_POST['otp']??'');
    if(empty($_SESSION['demo_otp'])||empty($_SESSION['public_user_id_pending']))
        {
            header('Location: ../index1.php');
            exit;
        }

        if($otp==$_SESSION['demo_otp'])
            {
                $_SESSION['public_user_id']=intval($_SESSION['public_user_id_pending']);
                unset($_SESSION['demo_otp'],$_SESSION['public_user_id_pending'],$_SESSION['demo_otp_mobile']);
                header('Location: ../index1.php');
                exit;
            }
            
            else
                {
                    echo "Invalid OTP. <a href='../index1.php'>Back</a>";
                }
