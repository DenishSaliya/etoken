<?php
    require_once '../config.php';

    $mobile=trim($_POST['mobile']??'');
    
    if(!$mobile)
        {
            header('Location: ../index1.php');
            exit;
        }

        $stmt=$conn->prepare("SELECT id FROM public_users WHERE mobile=?");
        $stmt->bind_param('s',$mobile);
        $stmt->execute();
        $r=$stmt->get_result()->fetch_assoc();


        if(!$r)
            {
                $ins=$conn->prepare("INSERT INTO public_users (mobile) VALUES (?)");
                $ins->bind_param('s',$mobile);
                $ins->execute();
                $id=$ins->insert_id;
            }
            else $id=$r['id'];

            $otp=rand(1000,9999);
            $_SESSION['demo_otp']=$otp;
            $_SESSION['demo_otp_mobile']=$mobile;
            $_SESSION['public_user_id_pending']=$id;

            header('Location: ../public_verify.php');
        exit;
