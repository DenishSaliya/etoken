<?php
    require_once '../config.php';
    unset($_SESSION['public_user_id']);
    header('Location: ../index1.php');