<?php
    require_once 'config.php';
    
    
    $mobile=trim($_REQUEST['mobile']??'');
    $token_no=trim($_REQUEST['token_no']??'');
    $stmt=$conn->prepare("SELECT t.*, p.first_name, d.name dept_name, c.title concern_title FROM tokens t JOIN public_users p ON t.public_user_id=p.id JOIN departments d ON t.department_id=d.id JOIN concerns c ON t.concern_id=c.id WHERE t.token_no=? AND p.mobile=?");
    $stmt->bind_param('ss',$token_no,$mobile);
    $stmt->execute();
    $row=$stmt->get_result()->fetch_assoc();
    
?>




<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Status</title>
        <link rel="stylesheet" href="assets/style.css">
    
    </head>
    
    <body>
        <div class="container"><h1>Token Status</h1>
        <?php if(!$row): ?>
            
            <div class="card"><p>No token found. <a href="index1.php">Back</a></p></div>
            <?php else: ?>
                
            <div class="status-box"><p><strong>Token:</strong>
            <?=$row['token_no']?></p>
            
            <p><strong>Department:</strong> <?=$row['dept_name']?></p>
            
            <p><strong>Concern:</strong>
            <?=$row['concern_title']?></p>
            
            <p><strong>Status:</strong>
            <?=$row['status']?></p>
            
            <p><strong>Updated:</strong>
            <?=$row['updated_at']?></p>
        </div>
        
        <p><a href="index1.php"><button>Home</button></a></p>
        <?php endif;?>
        </div>
    </body>
</html>
