<?php
    require_once '../config.php';
    unset($_SESSION['super_admin_id'],$_SESSION['super_admin_name']); 
    header('Location: login.php');