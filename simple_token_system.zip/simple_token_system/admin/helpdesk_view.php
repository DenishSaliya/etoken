<?php
// admin/helpdesk_view.php
session_start();
require_once(__DIR__ . "/../config.php");
if (empty($_SESSION['super_admin_id'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
if (!$id) { echo "Invalid ticket"; exit; }

$stmt = $conn->prepare("SELECT h.*, d.name as dept_name FROM helpdesk_tickets h LEFT JOIN departments d ON h.department_id=d.id WHERE h.id=?");
$stmt->bind_param("i",$id); $stmt->execute(); $ticket = $stmt->get_result()->fetch_assoc();
if (!$ticket) { echo "Ticket not found"; exit; }

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8"><title>View Ticket</title>
    <link rel="stylesheet" href="../assets/landing.css"></head>
<body>
  <div class="dashboard">
    <h2>Ticket: <?= htmlspecialchars($ticket['ticket_no']) ?></h2>
    <p><strong>Subject:</strong> <?= htmlspecialchars($ticket['subject']) ?></p>
    <p><strong>Name:</strong> <?= htmlspecialchars($ticket['name']) ?> | <strong>Mobile:</strong> <?= htmlspecialchars($ticket['mobile']) ?> | <strong>Email:</strong> <?= htmlspecialchars($ticket['email']) ?></p>
    <p><strong>Department:</strong> <?= htmlspecialchars($ticket['dept_name'] ?? '-') ?> | <strong>Priority:</strong> <?= htmlspecialchars($ticket['priority']) ?></p>
    <p><strong>Message:</strong><br><?= nl2br(htmlspecialchars($ticket['message'])) ?></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($ticket['status']) ?></p>
    <p><strong>Created:</strong> <?= $ticket['created_at'] ?> | <strong>SLA deadline:</strong> <?= $ticket['sla_deadline'] ?></p>
    <?php if ($ticket['admin_notes']): ?>
      <div style="background:#f7f7f7;padding:12px;border-radius:8px;margin-top:12px;"><strong>Admin Notes:</strong><br><?= nl2br(htmlspecialchars($ticket['admin_notes'])) ?></div>
    <?php endif; ?>

    <hr>
    <h3>Add admin note / resolve</h3>
    <form method="post" action="helpdesk_action.php">
      <input type="hidden" name="id" value="<?= $ticket['id'] ?>">
      <label class="small">Admin notes</label>
      <textarea name="admin_notes" rows="4" style="width:100%;padding:8px;border-radius:6px;"></textarea>
      <div style="margin-top:8px;">
        <button name="action" value="save_note" class="btn btn-primary">Save Note</button>
        <button name="action" value="resolve" class="btn btn-success">Mark Resolved</button>
      </div>
    </form>

    <p style="margin-top:12px;"><a href="helpdesk_tickets.php" class="btn btn-primary">Back to list</a></p>
  </div>
</body>
</html>
