<?php
// admin/helpdesk_action.php
session_start();
require_once(__DIR__ . "/../config.php");
if (empty($_SESSION['super_admin_id'])) { header('Location: login.php'); exit; }

$action = $_REQUEST['action'] ?? '';
$id = intval($_REQUEST['id'] ?? 0);

if (!$id) { header("Location: helpdesk_tickets.php"); exit; }

if ($action === 'resolve' || $_POST['action'] === 'resolve') {
    $stmt = $conn->prepare("UPDATE helpdesk_tickets SET status='Resolved', resolved_at=NOW(), admin_notes = CONCAT(IFNULL(admin_notes,''), ?) WHERE id=?");
    $note = "\n[Resolved by " . ($_SESSION['super_admin_name'] ?? 'admin') . " @ " . date('Y-m-d H:i:s') . "]\n" . (trim($_POST['admin_notes'] ?? '') ?: '');
    $stmt->bind_param("si", $note, $id);
    $stmt->execute();
    header("Location: helpdesk_view.php?id=$id");
    exit;
}

if ($action === 'save_note' || $_POST['action'] === 'save_note') {
    $note = trim($_POST['admin_notes'] ?? '');
    $stmt = $conn->prepare("UPDATE helpdesk_tickets SET admin_notes = CONCAT(IFNULL(admin_notes,''), ?) WHERE id=?");
    $note_full = "[Note by " . ($_SESSION['super_admin_name'] ?? 'admin') . " @ " . date('Y-m-d H:i:s') . "]\n" . $note . "\n";
    $stmt->bind_param("si", $note_full, $id);
    $stmt->execute();
    header("Location: helpdesk_view.php?id=$id");
    exit;
}

// fallback
header("Location: helpdesk_view.php?id=$id");
exit;
