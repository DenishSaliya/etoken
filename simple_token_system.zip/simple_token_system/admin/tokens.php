<?php
    require_once '../config.php';
    
    if(empty($_SESSION['super_admin_id']))
        {
            header('Location: login.php');
        exit;
    }

    if(isset($_GET['call_next'])&&isset($_GET['dept']))
        {
            $dept=intval($_GET['dept']);
            $stmt=$conn->prepare("SELECT id FROM tokens WHERE department_id=? AND status='waiting' ORDER BY created_at ASC LIMIT 1");
            $stmt->bind_param('i',$dept);
            $stmt->execute(); $row=$stmt->get_result()->fetch_assoc();
            
            if($row){ $id=$row['id'];
                $upd=$conn->prepare("UPDATE tokens SET status='called', updated_at=NOW() WHERE id=?");
                $upd->bind_param('i',$id);
                $upd->execute(); } header('Location: tokens.php?dept='.$dept);
            exit; }
            
    $dept=intval($_GET['dept']??0);
    $where=''; if($dept) $where='WHERE t.department_id='.$dept;
    $q=$conn->query("SELECT t.*, p.first_name, p.mobile, d.name dept_name, c.title concern_title FROM tokens t JOIN public_users p ON t.public_user_id=p.id JOIN departments d ON t.department_id=d.id JOIN concerns c ON t.concern_id=c.id $where ORDER BY t.created_at ASC");
    $depts=$conn->query("SELECT id,name FROM departments ORDER BY name")->fetch_all(MYSQLI_ASSOC);
?>



<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Tokens</title>
        <link rel="stylesheet" href="../assets/style.css">
    </head>
    <body>
        <div class="container"><h1>Manage Tokens</h1><p>
            <a href="dashboard.php">Back</a></p>
            
            <form method="get">
                <label>Department</label>
                <select name="dept" onchange="this.form.submit()">
                    <option value=''>All</option>
                    <?php
                        foreach($depts as $d):
                    ?>
                    
                    <option value='<?=$d['id']?>' <?=($dept==$d['id']?'selected':'')?>>
                        <?=htmlspecialchars($d['name'])?>
                    </option>
                        <?php
                            endforeach;
                        ?>
                </select>
            </form>
            <?php
                if($dept):
            ?>
            
            <p><a href="tokens.php?call_next=1&dept=<?=$dept?>">Call Next</a></p>
            <?php
                endif;
            ?>
            <table class="tbl">.
                <tr>
                    <th>ID</th>
                    <th>Token</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Dept</th>
                    <th>Concern</th>
                    <th>Status</th>
                    <th>Created</th>
                </tr>
            <?php
                while($r=$q->fetch_assoc()):
            ?>
            <tr>
                <td><?=$r['id']?></td>
                <td><?=htmlspecialchars($r['token_no'])?></td>
                <td><?=htmlspecialchars($r['first_name'])?></td>
                <td><?=htmlspecialchars($r['mobile'])?></td>
                <td><?=htmlspecialchars($r['dept_name'])?></td>
                <td><?=htmlspecialchars($r['concern_title'])?></td>
                <td><?=htmlspecialchars($r['status'])?></td>
                <td><?=$r['created_at']?></td>
            </tr>
            
            <?php
                endwhile;
            ?>
            </table>
        </div>
    </body>
    </html>
