<?php
// admin/helpdesk_tickets.php
session_start();
require_once(__DIR__ . "/../config.php");

// Basic auth check (use your existing super admin session variable)
if (empty($_SESSION['super_admin_id'])) {
    header('Location: login.php'); exit;
}

// Mark overdue tickets automatically (status remains 'Open' but flagged overdue)
$upd = $conn->prepare("UPDATE helpdesk_tickets SET status='Overdue' WHERE status='Open' AND sla_deadline < NOW()");
$upd->execute();

// Fetch tickets
$q = $conn->query("SELECT h.*, d.name as dept_name FROM helpdesk_tickets h LEFT JOIN departments d ON h.department_id=d.id ORDER BY h.created_at DESC");

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Helpdesk Tickets - Admin</title>
  <link rel="stylesheet" href="assets/landing.css">
  <style>
    .status-Open { color:#0b63d4; font-weight:600; }
    .status-Resolved { color:#28a745; font-weight:600; }
    .status-Overdue { color:#dc3545; font-weight:700; }
    .small { font-size:0.9rem; color:#666; }
    .actions a { margin-right:8px; }
  </style>
</head>
<body>
  <div class="dashboard">
    <h2>Help Desk Tickets</h2>
    <p class="small">Admin: <?=htmlspecialchars($_SESSION['super_admin_name'] ?? 'Admin')?></p>
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Ticket No</th><th>Subject</th><th>Dept</th><th>Priority</th><th>Status</th><th>Created</th><th>SLA left</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($r = $q->fetch_assoc()): 
            $sla_left = '';
            if ($r['status'] === 'Resolved') {
                $sla_left = '-';
            } else {
                $deadline = strtotime($r['sla_deadline']);
                $now = time();
                $diff = $deadline - $now;
                if ($diff <= 0) $sla_left = 'Overdue';
                else {
                    $h = floor($diff/3600); $m = floor(($diff%3600)/60);
                    $sla_left = "{$h}h {$m}m";
                }
            }
        ?>
        <tr>
          <td><?= $r['id'] ?></td>
          <td><?= htmlspecialchars($r['ticket_no']) ?></td>
          <td><?= htmlspecialchars($r['subject']) ?></td>
          <td><?= htmlspecialchars($r['dept_name'] ?? '-') ?></td>
          <td><?= htmlspecialchars($r['priority']) ?></td>
          <td class="status-<?= $r['status'] ?>"><?= htmlspecialchars($r['status']) ?></td>
          <td><?= $r['created_at'] ?></td>
          <td><?= $sla_left ?></td>
          <td class="actions">
            <a href="helpdesk_view.php?id=<?= $r['id'] ?>" class="btn btn-primary">View</a>
            <?php if ($r['status'] !== 'Resolved'): ?>
              <a href="helpdesk_action.php?action=resolve&id=<?= $r['id'] ?>" class="btn btn-success">Mark Resolved</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
