<?php
require_once '../config.php';
if
    (empty($_SESSION['super_admin_id']))
    { header('Location: login.php');
    exit; }
if
    ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action']) && $_POST['action']=='add_dept')
    { $name=trim($_POST['name']); $desc=trim($_POST['description']);
        $ins=$conn->prepare("INSERT INTO departments (name,description) VALUES (?,?)");
        $ins->bind_param('ss',$name,$desc);
        $ins->execute(); header('Location: dashboard.php');
        exit;
    }
if
    ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action']) && $_POST['action']=='add_concern')
    { $dept=intval($_POST['department_id']);
        $title=trim($_POST['title']);
        $ins=$conn->prepare("INSERT INTO concerns (department_id,title) VALUES (?,?)");
        $ins->bind_param('is',$dept,$title);
        $ins->execute(); header('Location: dashboard.php');
        exit;
    }
$depts=[];
$res=$conn->query("SELECT * FROM departments ORDER BY name");
while($r=$res->fetch_assoc())
    $depts[]=$r;
$concerns=[];
$qc=$conn->query("SELECT c.*, d.name dept_name FROM concerns c JOIN departments d ON c.department_id=d.id ORDER BY d.name, c.title");
while($r=$qc->fetch_assoc())
    $concerns[]=$r;
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container"><h1>Super Admin Dashboard</h1>
    <div class="nav"><a href="manage_dept_admins.php">Manage Dept Admins</a>
        <a href="tokens.php">Manage Tokens</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="dashboard-section">
        <h2>🆘 Help Desk</h2>
        <div class="card-grid">
    <div class="card">
        <h3>Open Tickets</h3>
        <p>
        <?php
            $r = $conn->query("SELECT COUNT(*) as c FROM helpdesk_tickets WHERE status='Open'");
            echo $r->fetch_assoc()['c'];
        ?>
      </p>
    </div>
    <div class="card">
      <h3>Overdue Tickets</h3>
      <p>
        <?php
          $r = $conn->query("SELECT COUNT(*) as c FROM helpdesk_tickets WHERE status='Overdue'");
          echo $r->fetch_assoc()['c'];
        ?>
      </p>
    </div>
    <div class="card">
      <h3>Resolved Tickets</h3>
      <p>
        <?php
          $r = $conn->query("SELECT COUNT(*) as c FROM helpdesk_tickets WHERE status='Resolved'");
          echo $r->fetch_assoc()['c'];
        ?>
      </p>
    </div>
  </div>
  <p style="margin-top:15px;">
    <a href="helpdesk_tickets.php" class="btn">View All Tickets</a>
  </p>
</div>


    <div class="card"><h3>Add Department</h3>
    <form method="post"><input type="hidden" name="action" value="add_dept"><label>Name</label>
        <input name="name" required><label>Description</label>
        <input name="description">
        <button>Add Department</button>
    </form>
    </div>
    <div class="card"><h3>Add Concern</h3>
    <form method="post"><input type="hidden" name="action" value="add_concern"><label>Department</label>
    <select name="department_id" required>
        <option value=''>--select--</option>
    <?php foreach($depts as $d): ?>
        <option value='<?=$d['id']?>'><?=htmlspecialchars($d['name'])?></option>
    <?php endforeach; ?>
    </select>
    <label>Title</label>
    <input name="title" required>
    <button>Add Concern</button>
    </form>
    </div>
    <div class="card"><h3>Departments</h3>
        <table class="tbl">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
            </tr>
        <?php foreach($depts as $d): ?>
            <tr>
                <td><?=$d['id']?></td>
                <td><?=htmlspecialchars($d['name'])?></td>
                <td><?=htmlspecialchars($d['description'])?></td>
            </tr>
        <?php endforeach; ?>
        </table>
    </div>
    </div>
</body>
</html>
