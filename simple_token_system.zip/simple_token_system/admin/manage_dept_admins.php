<?php
    require_once '../config.php';
    
    if
        (empty($_SESSION['super_admin_id'])){ header('Location: login.php');
    exit; }
    $msg='';
    if
    (isset($_POST['add_admin']))
        {
            $name=trim($_POST['name']);
            $email=trim($_POST['email']);
            $password=md5($_POST['password']);
            $dept_id=intval($_POST['department']);
            $stmt=$conn->prepare("INSERT INTO dept_admins (name,email,password,department_id) VALUES (?,?,?,?)");
            $stmt->bind_param('sssi',$name,$email,$password,$dept_id);
            $stmt->execute(); $msg='Department Admin created';
        }

        $dept_result=$conn->query("SELECT * FROM departments");
        $admins_result=$conn->query("SELECT da.*, d.name as dept_name FROM dept_admins da JOIN departments d ON da.department_id=d.id"); 
?>



<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Manage Dept Admins</title>
        <link rel="stylesheet" href="../assets/style.css">
    </head>
<body>
    <div class="container"><h1>Manage Department Admins</h1>
    <?php
        if($msg) echo '<p style="color:green;">'.$msg.'</p>';
    ?>
    
    <div class="card">
        <form method="post">
            <label>Full Name</label><input name="name" required>
            <label>Email</label><input name="email" required>
            <label>Password</label><input type="password" name="password" required>
            <label>Department</label><select name="department" required><option value=''>Select</option>
        
        <?php
            while($row=$dept_result->fetch_assoc()):
        ?>
        
        <option value='
            <?=$row['id']?>'>
            <?=htmlspecialchars($row['name'])?>
        </option>
        
        <?php
            endwhile;
        ?>
        
        </select>
        <button name="add_admin">Create Dept Admin</button>
        </form>
    </div>
    <div class="card"><h3>Existing Dept Admins</h3>
        <table class="tbl">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Dept</th>
            </tr>
            
            <?php
                while($a=$admins_result->fetch_assoc()):
            ?>
            <tr>
                <td><?=$a['id']?></td>
                <td><?=htmlspecialchars($a['name'])?></td>
                <td><?=htmlspecialchars($a['email'])?></td>
                <td><?=htmlspecialchars($a['dept_name'])?></td>
            </tr>
            
            <?php
                endwhile;
            ?>
        </table>
    </div>
    </div>
</body>
</html>
