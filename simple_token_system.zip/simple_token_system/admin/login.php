<?php
    require_once '../config.php';
    if($_SERVER['REQUEST_METHOD']==='POST')
        { $email=$_POST['email']??'';
        $pass=$_POST['password']??'';
        $stmt=$conn->prepare("SELECT id,name FROM super_admins WHERE email=? AND password=MD5(?)");
        $stmt->bind_param('ss',$email,$pass);
        $stmt->execute();
        $r=$stmt->get_result()->fetch_assoc();
        
    if($r){ $_SESSION['super_admin_id']=$r['id'];
        $_SESSION['super_admin_name']=$r['name'];
        header('Location: dashboard.php');
    exit; }
        else $err='Invalid'; }
        
?>


<!doctype html>
<html>
    <head>.
        <meta charset="utf-8"><title>Admin Login</title>
        <link rel="stylesheet" href="../assets/style.css">
    </head>
<body>
    <div class="container"><h1>Super Admin Login</h1>
    <div class="card">
        <?php
            if(!empty($err)) echo '<p style="color:red;">'.$err.'</p>';
        ?>
        
        <form method="post">
            <label>Email</label><input name="email" required>
            <label>Password</label><input type="password" name="password" required>
            <button>Login</button>
        </form>
    </div>
    </div>
</body>
</html>
