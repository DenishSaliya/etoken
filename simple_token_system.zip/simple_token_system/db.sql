-- db.sql
CREATE DATABASE IF NOT EXISTS govtoken CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE govtoken;

CREATE TABLE IF NOT EXISTS super_admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS departments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS concerns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  department_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS dept_admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  department_id INT NOT NULL,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS public_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100),
  middle_name VARCHAR(100),
  last_name VARCHAR(100),
  gender ENUM('Male','Female','Other') DEFAULT 'Male',
  age INT,
  mobile VARCHAR(20) NOT NULL,
  email VARCHAR(150),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  token_no VARCHAR(50) NOT NULL,
  public_user_id INT NOT NULL,
  department_id INT NOT NULL,
  concern_id INT NOT NULL,
  status ENUM('waiting','called','processing','completed','skipped') DEFAULT 'waiting',
  called_by_dept_admin_id INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (public_user_id) REFERENCES public_users(id) ON DELETE CASCADE,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE,
  FOREIGN KEY (concern_id) REFERENCES concerns(id) ON DELETE CASCADE
);

INSERT INTO super_admins (name,email,password) VALUES ('Super Admin','admin@example.com', MD5('admin123'));
INSERT INTO departments (name,description) VALUES ('Passport', 'Passport related services'), ('Income Tax', 'Income tax department');
INSERT INTO concerns (department_id,title) VALUES (1,'New Passport'), (1,'Passport Renewal'), (2,'PAN Card'), (2,'Tax Return');
