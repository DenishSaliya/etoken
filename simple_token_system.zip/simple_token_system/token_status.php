<?php
require_once(__DIR__ . "/config.php");

$statusData = null;
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mobile = $_POST['mobile'] ?? '';

    if (!empty($mobile)) {
        $stmt = $conn->prepare("SELECT t.token_no, t.status, d.name AS department, c.title AS concern, u.first_name, u.last_name, t.created_at
                                FROM tokens t
                                JOIN departments d ON t.department_id = d.id
                                JOIN concerns c ON t.concern_id = c.id
                                JOIN public_users u ON t.public_user_id = u.id
                                WHERE u.mobile = ?
                                ORDER BY t.created_at DESC
                                LIMIT 1");
        $stmt->bind_param("s", $mobile);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $statusData = $result->fetch_assoc();
        } else {
            $error = "❌ No tokens found for this mobile number.";
        }
    } else {
        $error = "⚠️ Please enter a mobile number.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Check Token by Mobile - GovToken</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    .status-box {
      background: #fff;
      padding: 20px;
      margin-top: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .status-box p { margin: 8px 0; }
    .status-box strong { color: #003366; }
    .error { color: red; margin-top: 15px; text-align: center; }
  </style>
</head>
<body>
  <div class="container">
    <h2>📱 Check Your Token Status by Mobile</h2>
    <form method="POST">
      <label for="mobile">Enter Mobile Number</label>
      <input type="text" name="mobile" placeholder="e.g. 9876543210" required>
      <button type="submit">Check Status</button>
    </form>

    <?php if ($error): ?>
      <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <?php if ($statusData): ?>
    <div class="status-box">
      <h3>📋 Latest Token Details</h3>
      <p><strong>Token Number:</strong> <?= $statusData['token_no'] ?></p>
      <p><strong>Name:</strong> <?= $statusData['first_name'] . " " . $statusData['last_name'] ?></p>
      <p><strong>Department:</strong> <?= $statusData['department'] ?></p>
      <p><strong>Concern:</strong> <?= $statusData['concern'] ?></p>
      <p><strong>Status:</strong> <?= ucfirst($statusData['status']) ?></p>
      <p><strong>Issued At:</strong> <?= $statusData['created_at'] ?></p>
    </div>
    <?php endif; ?>
  </div>
</body>
</html>
