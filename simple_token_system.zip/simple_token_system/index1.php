<?php
  require_once 'config.php';


  $departments=[];
  $dq=$conn->query("SELECT id,name FROM departments ORDER BY name");

  while
    ($r=$dq->fetch_assoc())
    $departments[]=$r;

    $public_user=null;
    if(!empty($_SESSION['public_user_id']))
      {
        $uid=intval($_SESSION['public_user_id']);
        $stmt=$conn->prepare("SELECT * FROM public_users WHERE id=?");
        $stmt->bind_param('i',$uid);
        $stmt->execute();
        $public_user=$stmt->get_result()->fetch_assoc();
      }
?>


<!doctype html>
<html>
  <head>
    <meta charset="utf-8"><title>E Token Service - Book Token</title>
    <link rel="stylesheet" href="assets/style.css">
  </head>
  <body>

  <div class="container"><h1>E Token Service - Book Token</h1>

  <?php if(!$public_user): ?>

    <div class="card"><h3>Login with Mobile (demo)</h3>
    <form method="post" action="public_api/login_mobile.php">
    <label>Mobile number</label><input name="mobile" required placeholder="e.g. 9876543210">
    <button type="submit">Send OTP (demo)</button>
  </form>
  <p>OTP displayed for demo.</p></div>

  <?php else: ?>
    <div class="card"><h3>Welcome <?=htmlspecialchars($public_user['first_name']?:$public_user['mobile'])?> <small><a href="public_api/logout.php">Logout</a></small></h3>
        <form method="post" action="public_api/book_token.php">

          <label>First name</label><input name="first_name" required value="<?=htmlspecialchars($public_user['first_name'])?>">
          <label>Middle name</label><input name="middle_name" value="<?=htmlspecialchars($public_user['middle_name'])?>">
          <label>Last name</label><input name="last_name" value="<?=htmlspecialchars($public_user['last_name'])?>">
          <label>Gender</label>
          <select name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          <label>Age</label><input name="age" type="number" required value="<?=htmlspecialchars($public_user['age'])?>">
          <label>Mobile</label><input name="mobile" required value="<?=htmlspecialchars($public_user['mobile'])?>">
          <label>Email</label><input name="email" value="<?=htmlspecialchars($public_user['email'])?>">
          <label>Department</label>
          <select id="department_id" name="department_id" onchange="loadConcerns(this.value); showLiveCrowd();" required>
            <option value="">--select--</option>
            <?php foreach($departments as $d): ?>
              <option value="<?=$d['id']?>"><?=htmlspecialchars($d['name'])?></option>
            <?php endforeach; ?>
          </select>
          <label>Concern</label>
          <select id="concern_id" name="concern_id" required><option value="">Select department first</option></select>

          <p>Live crowd waiting for selected department: <b id="live_crowd">0</b></p>

          <button type="submit">Book Token</button>
        </form>
      </div>
    <?php endif; ?>


  </div>

  
  </div>


    <script>
      function loadConcerns(dept)
      {
        fetch('public_api/get_concerns.php?dept='+dept).then(r=>r.json()).then(data=>{ let sel=document.getElementById('concern_id');
        sel.innerHTML='';
        data.forEach(c=>{ let opt=document.createElement('option');
          opt.value=c.id;
          opt.text=c.title;
          sel.add(opt);
          });
        });
      }

      function showLive()
      {
        let dept=document.getElementById('department_id');
        if(!dept)return;
        
        fetch('public_api/live_crowd.php?dept='+dept.value).then(r=>r.json()).then(d=>document.getElementById('live_crowd').innerText=d.waiting||0);
      }
    setInterval(showLive,3000);
    </script>
  </body>
</html>
