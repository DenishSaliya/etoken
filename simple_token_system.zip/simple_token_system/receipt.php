<?php
    require_once 'config.php';
    
    $token_no=$_GET['token_no']??'';
    $stmt=$conn->prepare("SELECT t.*, p.first_name, p.mobile, d.name dept_name, c.title concern_title FROM tokens t JOIN public_users p ON t.public_user_id=p.id JOIN departments d ON t.department_id=d.id JOIN concerns c ON t.concern_id=c.id WHERE t.token_no=?");
    $stmt->bind_param('s',$token_no);
    $stmt->execute();
    $row=$stmt->get_result()->fetch_assoc();
    
    if(!$row)
        {
            echo "Invalid token";
            exit;
        }
?>




<!doctype html>
<html>
    <head>
        <meta charset="utf-8"><title>Receipt</title>
        <link rel="stylesheet" href="assets/style.css">
    </head>
    <body>
        
        <div class="container"><h1>Token Receipt</h1>
        <div class="receipt"><p>
            <strong>Token No:</strong>
            
            <?=$row['token_no']?></p>
            <p><strong>Name:</strong>
            <?=htmlspecialchars($row['first_name'])?></p>

            <p><strong>Mobile:</strong>
            <?=htmlspecialchars($row['mobile'])?></p>
            
            <p><strong>Department:</strong>
            <?=htmlspecialchars($row['dept_name'])?></p>
            
            <p><strong>Concern:</strong>
            <?=htmlspecialchars($row['concern_title'])?></p>
            
            <p><strong>Status:</strong>
            <?=htmlspecialchars($row['status'])?></p>
        </div><p>
            
        <a href="index1.php">
            <button>Home</button>
        </a>
        
        <button onclick="window.print()">Print</button></p>
        </div>
    </body>
</html>
