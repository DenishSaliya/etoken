<?php
// helpdesk.php
require_once(__DIR__ . "/config.php");

// Load departments for select (optional)
$departments = [];
$dr = $conn->query("SELECT id, name FROM departments ORDER BY name");
while ($r = $dr->fetch_assoc()) $departments[] = $r;

$success = null;
$error = null;
$ticket_no = null;
if (!empty($_GET['success']) && !empty($_GET['ticket_no'])) {
    $success = "Ticket created successfully. Your Ticket No: " . htmlspecialchars($_GET['ticket_no']);
    $ticket_no = htmlspecialchars($_GET['ticket_no']);
}
if (!empty($_GET['error'])) $error = htmlspecialchars($_GET['error']);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Help Desk - E-Token</title>
  <link rel="stylesheet" href="assets/landing.css">
  <style>
    .small { font-size:0.9rem; color:#555; }
    .status-open { color:#0b63d4; font-weight:700; }
    .status-resolved { color:#28a745; font-weight:700; }
    .status-overdue { color:#dc3545; font-weight:700; }
    .hint { margin-top:8px; font-size:0.9rem; color:#333; }
  </style>
</head>
<body>
  <header class="hero" style="height:220px; padding-top:30px;">
    <div class="hero-content">
      <h1>Help Desk</h1>
      <p class="small">Submit an issue — our team will respond within <strong>24 hours</strong>.</p>
    </div>
  </header>

  <div class="form-container" style="max-width:760px;">
    <?php if ($error): ?>
      <div class="alert alert-error"><?= $error ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <form action="helpdesk_submit.php" method="post">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email (optional)">
      <input type="text" name="mobile" placeholder="Mobile (10 digits)" pattern="[0-9]{10}">
      <label class="small">Department (optional)</label>
      <select name="department_id">
        <option value="">-- Select Department --</option>
        <?php foreach($departments as $d): ?>
          <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['name']) ?></option>
        <?php endforeach; ?>
      </select>

      <input type="text" name="subject" placeholder="Subject" required>
      <label class="small">Priority</label>
      <select name="priority" required>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
        <option value="High">High</option>
      </select>
      <textarea name="message" placeholder="Describe your issue in detail" rows="6" required></textarea>

      <p class="hint">By submitting you agree that we may contact you about this ticket. Estimated resolution: within 24 hours.</p>
      <button type="submit">Submit Ticket</button>
    </form>
  </div>

  <footer style="margin-top:40px;">
    <p style="text-align:center;color:#666;padding:30px 0">E-Token Help Desk</p>
  </footer>
</body>
</html>
