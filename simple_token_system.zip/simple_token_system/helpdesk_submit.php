<?php
// helpdesk_submit.php
require_once(__DIR__ . "/config.php");

// Basic server-side validation & sanitization
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$mobile = trim($_POST['mobile'] ?? '');
$department_id = !empty($_POST['department_id']) ? intval($_POST['department_id']) : null;
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');
$priority = in_array($_POST['priority'] ?? 'Medium', ['Low','Medium','High']) ? $_POST['priority'] : 'Medium';

if ($name === '' || $subject === '' || $message === '') {
    header("Location: helpdesk.php?error=" . urlencode("Please fill required fields"));
    exit;
}

// Generate a readable ticket number: HD-YYYYMMDD-XXXX
$date = date('Ymd');
$rand = mt_rand(100,999);
$ticket_no = "HD-{$date}-{$rand}";

// Compute SLA deadline (24 hours)
$created_at = date('Y-m-d H:i:s');
$sla_deadline = date('Y-m-d H:i:s', strtotime('+24 hours'));

$stmt = $conn->prepare("INSERT INTO helpdesk_tickets (ticket_no, name, email, mobile, department_id, subject, message, priority, status, created_at, sla_deadline) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?)");
$stmt->bind_param("ssssisssss", $ticket_no, $name, $email, $mobile, $department_id, $subject, $message, $priority, $created_at, $sla_deadline);

if ($stmt->execute()) {
    // Success - redirect to helpdesk with ticket no
    header("Location: helpdesk.php?success=1&ticket_no=" . urlencode($ticket_no));
    exit;
} else {
    header("Location: helpdesk.php?error=" . urlencode("Unable to create ticket, please try later"));
    exit;
}
